module.exports = {
    qq:{
        clientID        : "101180058",
        clientSecret    : "1175002b7123b2c9377b51dff00c4d76",
        callbackURL     : "http://www.iwoor.com/auth/qq/callback"
    },
    weibo:{
        clientID        : "1473012958",
        clientSecret    : "60c8f74483f319537f24b017a1b6b623",
        callbackURL     : "http://www.iwoor.com/auth/weibo/callback"
    },
    renren:{
        clientID        : "473985",
        clientSecret    : "8b52b1894ef447d1b694026b5247d5c9",
        callbackURL     : "http://www.iwoor.com/auth/renren/callback"
    },
    douban:{
        clientID        : "0d25dfabcf764b7c27719f036e62e274",
        clientSecret    : "2ac2c538d6e7a70f",
        callbackURL     : "http://www.iwoor.com/auth/douban/callback"
    }
};