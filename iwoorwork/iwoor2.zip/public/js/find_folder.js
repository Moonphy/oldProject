var blockData = { numOfCol:3, offsetX: 5, offsetY: 9 };

$(function(){
    $('#folders').BlocksIt(blockData);
});
