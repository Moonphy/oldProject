var WebSite = require('../models/WebSiteModel');
var WebFolder = require('../models/WebFolderModel');
var Member = require('../models/MemberModel');

exports.test = function(req,res){
    /*var member = {name:'test',image:'http://i0.moihu.com/images/face/big/face_1102_100x100.jpg'};

    Member.create(member,function(err,result){
        var folder = new WebFolder({
            name:'test-folder',
            member:result._id
        });

        folder.save(function(err,result){
            console.log(result);
            res.send('ok');
        });

    });

*/
    WebFolder.findOne({}).populate('member').exec(function(err,folder){
        res.render('test',{name:folder.name,member:folder.member.name});
    });

};
