var express = require('express');
var router = express.Router();


var findController  = require('../controllers/FindController');

router.get('/test',findController.test);


router.get('/find.html',function(req,res){
    res.render('find');
});

router.get('/find_folder.html',function(req,res){
    res.render('find_folder');
});

router.get('/find_user.html',function(req,res){
    res.render('find_user');
});


module.exports = router;