var path = require('path');

var config = {
    // mongodb 配置
    db: 'mongodb://127.0.0.1/iwoor',
    db_name: 'iwoor'
};

module.exports = config;